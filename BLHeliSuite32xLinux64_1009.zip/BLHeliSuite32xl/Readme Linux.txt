FAQ
//to have access to com/USB ports one can add the user to dialout group with command like
sudo usermod -a -G dialout $USER

//for test playing Music inside the editor needs vlc
sudo apt install vlc

//In order to get permanent access to FVT_linker you can add a udev rule file
sudoedit /etc/udev/rules.d/50-FVT-Linker.rules
//paste this line in there
KERNEL=="hidraw*", SUBSYSTEM=="hidraw", ATTRS{idVendor}=="10c4", ATTRS{idProduct}=="8468", TAG+="uaccess", GROUP="plugdev", MODE="0660"

//After saving the file logot or:
sudo udevadm control --reload-rules
sudo udevadm trigger

//due to libcurl3/libcurl4 conflict, a split into legacy (marked as legacy) and regular version was needed.
- regular version uses libcurl4, which is available on Ubuntu 19 etc.
- if regular doesn't start, use legacy version (Ubuntu 16 etc).